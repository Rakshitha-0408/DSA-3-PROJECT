NEWS & SOCIAL MEDIA ANALYTICS ENGINE - JAVA + WEB VERSION

Project architecture:
- Java = actual DSA engine
- Node.js + Express = web/API server
- HTML/CSS/JavaScript = dashboard frontend
- CSV = dataset

Requirements:
- Java JDK 17 or above
- Node.js
- VS Code (recommended)

Run:
1. Open the project folder in VS Code.
2. Open a terminal in the project folder.
3. Run:
   node server.js
4. Open:
   http://localhost:3000

The server automatically compiles the Java source files into the out/ folder.

Page flow:
http://localhost:3000
    -> Landing page
    -> LET'S START
    -> /dashboard
    -> Dashboard

Refreshing the dashboard returns to the landing page.

DSA implemented and exposed through the web API:
1. Hash Table - duplicate detection
2. Max Heap - priority ranking
3. TreeMap-based Topic Tree - topic organization
4. Queue - moderation/incoming post processing
5. Graph with adjacency lists - content relationships
6. Linear search - keyword search
7. Topic-based clustering - related story grouping
8. Round-robin moderator assignment

Web API endpoints:
- GET /api/posts
- GET /api/stats
- GET /api/search?q=metro
- GET /api/duplicates
- GET /api/ranking
- GET /api/clusters
- GET /api/moderation
- GET /api/relationships

Important:
The dashboard does not use a separate hard-coded JavaScript dataset for its analytics.
The frontend requests data from Node.js, and Node.js executes the Java DSA API.
