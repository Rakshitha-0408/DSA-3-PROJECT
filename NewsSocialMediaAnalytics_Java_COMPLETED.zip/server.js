const express = require("express");
const path = require("path");
const fs = require("fs");
const { spawnSync } = require("child_process");

const app = express();
const PORT = 3000;

const ROOT = __dirname;
const FRONTEND = path.join(ROOT, "frontend");
const SRC = path.join(ROOT, "src");
const OUT = path.join(ROOT, "out");

process.chdir(ROOT);

function compileJava() {
    fs.mkdirSync(OUT, { recursive: true });

    const javaFiles = fs.readdirSync(SRC)
        .filter(file => file.endsWith(".java"))
        .map(file => path.join(SRC, file));

    const compiler = process.platform === "win32" ? "javac.exe" : "javac";

    const result = spawnSync(compiler, ["-d", OUT, ...javaFiles], {
        encoding: "utf8"
    });

    if (result.status !== 0) {
        console.error("Java compilation failed:");
        console.error(result.stderr || result.stdout);
        process.exit(1);
    }

    console.log("Java DSA engine compiled successfully.");
}

compileJava();

function runJava(command, args = []) {
    const java = process.platform === "win32" ? "java.exe" : "java";

    const result = spawnSync(
        java,
        ["-cp", OUT, "Api", command, ...args],
        {
            cwd: ROOT,
            encoding: "utf8",
            maxBuffer: 10 * 1024 * 1024
        }
    );

    if (result.error) throw result.error;

    if (result.status !== 0) {
        throw new Error(result.stderr || result.stdout || "Java process failed.");
    }

    const output = (result.stdout || "").trim();

    try {
        return JSON.parse(output);
    } catch (error) {
        console.error("Invalid Java JSON output:");
        console.error(output);
        throw new Error("Java DSA engine returned invalid data.");
    }
}

app.use(express.json());

app.use(express.static(FRONTEND, { index: false }));

app.get("/", (req, res) => {
    res.sendFile(path.join(FRONTEND, "landing.html"));
});

app.get("/dashboard", (req, res) => {
    res.sendFile(path.join(FRONTEND, "index.html"));
});

app.get("/api/posts", (req, res) => {
    try { res.json(runJava("posts")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.get("/api/stats", (req, res) => {
    try { res.json(runJava("stats")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.get("/api/search", (req, res) => {
    try {
        const query = typeof req.query.q === "string" ? req.query.q : "";
        res.json(runJava("search", [query]));
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get("/api/duplicates", (req, res) => {
    try { res.json(runJava("duplicates")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.get("/api/ranking", (req, res) => {
    try { res.json(runJava("ranking")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.get("/api/clusters", (req, res) => {
    try { res.json(runJava("clusters")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.get("/api/moderation", (req, res) => {
    try { res.json(runJava("moderation")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.get("/api/relationships", (req, res) => {
    try { res.json(runJava("relationships")); }
    catch (error) { res.status(500).json({ error: error.message }); }
});

app.listen(PORT, () => {
    console.log("=================================");
    console.log(" News & Social Media Analytics");
    console.log(" Server started successfully!");
    console.log("=================================");
    console.log(`Open: http://localhost:${PORT}`);
    console.log("Java DSA API: connected");
});
