import java.util.*;

public class Moderator {

    private static final String[] moderators = {
        "Moderator_A",
        "Moderator_B",
        "Moderator_C"
    };

    public static void assignModerators(ArrayList<Post> posts) {

        System.out.println("\n==============================================");
        System.out.println(" MODERATOR ASSIGNMENT");
        System.out.println("==============================================");

        int index = 0;

        for (Post post : posts) {

            String moderator = moderators[index % moderators.length];

            System.out.println(
                "Post " + post.id +
                " → " + moderator
            );

            index++;
        }
    }
}