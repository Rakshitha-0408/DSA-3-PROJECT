import java.io.*;
import java.util.*;

public class CSVReader {
    public static ArrayList<Post> read(String file) {
        ArrayList<Post> posts = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            br.readLine(); // header

            while ((line = br.readLine()) != null) {
                String[] p = line.split(",", -1);
                if (p.length >= 6) {
                    posts.add(new Post(
                        Integer.parseInt(p[0]),
                        p[1],
                        p[2],
                        p[3],
                        p[4],
                        Integer.parseInt(p[5])
                    ));
                }
            }
        } catch (Exception e) {
            System.out.println("Error reading CSV: " + e.getMessage());
        }

        return posts;
    }
}
