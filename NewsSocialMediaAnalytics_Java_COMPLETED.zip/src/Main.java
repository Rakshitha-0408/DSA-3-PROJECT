import java.util.*;

public class Main {

    static String normalize(String text) {
        return text.toLowerCase()
                   .replaceAll("[^a-z0-9 ]", " ")
                   .replaceAll("\\s+", " ")
                   .trim();
    }

    static void search(ArrayList<Post> posts, String query) {
        System.out.println("\n--- SEARCH RESULTS: " + query + " ---");
        String q = query.toLowerCase();

        for (Post p : posts) {
            if (p.title.toLowerCase().contains(q) ||
                p.content.toLowerCase().contains(q) ||
                p.topic.toLowerCase().contains(q)) {
                System.out.println(p);
            }
        }
    }

    static void duplicateDetection(ArrayList<Post> posts) {
        System.out.println("\n--- DUPLICATE DETECTION ---");
        HashTable table = new HashTable();

        for (Post p : posts) {
            String key = normalize(p.content);

            if (table.contains(key)) {
                System.out.println("Post " + p.id +
                    " is duplicate of Post " + table.get(key));
            } else {
                table.put(key, p.id);
            }
        }
    }

    static void ranking(ArrayList<Post> posts) {
        System.out.println("\n--- PRIORITY RANKING USING MAX HEAP ---");
        MaxHeap heap = new MaxHeap();

        for (Post p : posts)
            heap.insert(p);

        Post p;
        while ((p = heap.removeMax()) != null)
            System.out.println(p);
    }

    static void queueDemo(ArrayList<Post> posts) {
        System.out.println("\n--- MODERATION QUEUE ---");
        PostQueue queue = new PostQueue();

        for (Post p : posts)
            queue.enqueue(p);

        System.out.println("Posts waiting for moderation: " + queue.size());

        Post next = queue.dequeue();
        if (next != null)
            System.out.println("Next post for moderation: " + next);
    }

    static void graphDemo(ArrayList<Post> posts) {
        Graph graph = new Graph();

        for (Post p : posts)
            graph.addEdge("Topic:" + p.topic, "Post:" + p.id);

        graph.display();
    }

    public static void main(String[] args) {
        ArrayList<Post> posts = CSVReader.read("data/news_posts.csv");

        System.out.println("==============================================");
        System.out.println(" NEWS & SOCIAL MEDIA ANALYTICS ENGINE");
        System.out.println("==============================================");
        System.out.println("Total posts loaded: " + posts.size());

        search(posts, "metro");
        duplicateDetection(posts);
        ranking(posts);

        TopicTree tree = new TopicTree();
        for (Post p : posts)
            tree.add(p);
        tree.display();
        Clustering.displayClusters(posts);

        Moderator.assignModerators(posts);

        queueDemo(posts);
        graphDemo(posts);

        System.out.println("\nProject execution completed.");
    }
}
