import java.util.*;

public class Api {

    static String normalize(String text) {
        return text.toLowerCase()
                .replaceAll("[^a-z0-9 ]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static String esc(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t");
    }

    static String postJson(Post p) {
        return "{\"id\":" + p.id
                + ",\"title\":\"" + esc(p.title)
                + "\",\"content\":\"" + esc(p.content)
                + "\",\"source\":\"" + esc(p.sourceType)
                + "\",\"topic\":\"" + esc(p.topic)
                + "\",\"priority\":" + p.priority + "}";
    }

    static ArrayList<Post> loadPosts() {
        return CSVReader.read("data/news_posts.csv");
    }

    static void allPosts() {
        ArrayList<Post> posts = loadPosts();
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < posts.size(); i++) {
            if (i > 0) out.append(",");
            out.append(postJson(posts.get(i)));
        }
        out.append("]");
        System.out.println(out);
    }

    static void stats() {
        ArrayList<Post> posts = loadPosts();
        HashSet<String> topics = new HashSet<>();
        for (Post p : posts) topics.add(p.topic);

        HashTable table = new HashTable();
        int duplicates = 0;
        for (Post p : posts) {
            String key = normalize(p.content);
            if (table.contains(key)) duplicates++;
            else table.put(key, p.id);
        }

        System.out.println(
            "{\"totalPosts\":" + posts.size()
            + ",\"totalTopics\":" + topics.size()
            + ",\"totalDuplicates\":" + duplicates
            + ",\"moderationCount\":" + posts.size() + "}"
        );
    }

    static void search(String query) {
        ArrayList<Post> posts = loadPosts();
        String q = query == null ? "" : query.toLowerCase().trim();
        StringBuilder out = new StringBuilder("[");
        boolean first = true;

        if (!q.isEmpty()) {
            for (Post p : posts) {
                if (p.title.toLowerCase().contains(q)
                        || p.content.toLowerCase().contains(q)
                        || p.topic.toLowerCase().contains(q)) {
                    if (!first) out.append(",");
                    out.append(postJson(p));
                    first = false;
                }
            }
        }
        out.append("]");
        System.out.println(out);
    }

    static void duplicates() {
        ArrayList<Post> posts = loadPosts();
        HashTable table = new HashTable();
        StringBuilder out = new StringBuilder("[");
        boolean first = true;

        for (Post p : posts) {
            String key = normalize(p.content);
            if (table.contains(key)) {
                if (!first) out.append(",");
                out.append("{\"original\":")
                   .append(postJson(findPost(posts, table.get(key))))
                   .append(",\"duplicate\":")
                   .append(postJson(p))
                   .append("}");
                first = false;
            } else {
                table.put(key, p.id);
            }
        }
        out.append("]");
        System.out.println(out);
    }

    static Post findPost(ArrayList<Post> posts, int id) {
        for (Post p : posts) if (p.id == id) return p;
        return null;
    }

    static void ranking() {
        ArrayList<Post> posts = loadPosts();
        MaxHeap heap = new MaxHeap();
        for (Post p : posts) heap.insert(p);

        StringBuilder out = new StringBuilder("[");
        boolean first = true;
        Post p;
        while ((p = heap.removeMax()) != null) {
            if (!first) out.append(",");
            out.append(postJson(p));
            first = false;
        }
        out.append("]");
        System.out.println(out);
    }

    static void clusters() {
        ArrayList<Post> posts = loadPosts();
        Map<String, ArrayList<Post>> clusters = Clustering.clusterByTopic(posts);
        StringBuilder out = new StringBuilder("[");
        boolean firstCluster = true;

        for (String topic : clusters.keySet()) {
            if (!firstCluster) out.append(",");
            firstCluster = false;
            out.append("{\"topic\":\"").append(esc(topic)).append("\",\"posts\":[");

            ArrayList<Post> clusterPosts = clusters.get(topic);
            for (int i = 0; i < clusterPosts.size(); i++) {
                if (i > 0) out.append(",");
                out.append(postJson(clusterPosts.get(i)));
            }
            out.append("]}");
        }
        out.append("]");
        System.out.println(out);
    }

    static void moderation() {
        ArrayList<Post> posts = loadPosts();
        String[] moderators = {"Moderator_A", "Moderator_B", "Moderator_C"};

        StringBuilder out = new StringBuilder();
        out.append("{\"assignments\":[");
        for (int i = 0; i < posts.size(); i++) {
            if (i > 0) out.append(",");
            out.append("{\"postId\":").append(posts.get(i).id)
               .append(",\"moderator\":\"")
               .append(moderators[i % moderators.length])
               .append("\"}");
        }

        out.append("],\"queue\":[");
        PostQueue queue = new PostQueue();
        for (Post p : posts) queue.enqueue(p);
        boolean first = true;
        Post next;
        while ((next = queue.dequeue()) != null) {
            if (!first) out.append(",");
            out.append(postJson(next));
            first = false;
        }
        out.append("]}");
        System.out.println(out);
    }

    static void relationships() {
        ArrayList<Post> posts = loadPosts();
        Map<String, ArrayList<Post>> groups = new TreeMap<>();
        for (Post p : posts) {
            groups.computeIfAbsent(p.topic, k -> new ArrayList<>()).add(p);
        }

        StringBuilder out = new StringBuilder("[");
        boolean firstGroup = true;
        for (String topic : groups.keySet()) {
            if (!firstGroup) out.append(",");
            firstGroup = false;
            out.append("{\"topic\":\"").append(esc(topic)).append("\",\"posts\":[");

            ArrayList<Post> topicPosts = groups.get(topic);
            for (int i = 0; i < topicPosts.size(); i++) {
                if (i > 0) out.append(",");
                out.append(postJson(topicPosts.get(i)));
            }
            out.append("]}");
        }
        out.append("]");
        System.out.println(out);
    }

    public static void main(String[] args) {
        String command = args.length > 0 ? args[0].toLowerCase() : "all";
        switch (command) {
            case "posts": allPosts(); break;
            case "stats": stats(); break;
            case "search": search(args.length > 1 ? args[1] : ""); break;
            case "duplicates": duplicates(); break;
            case "ranking": ranking(); break;
            case "clusters": clusters(); break;
            case "moderation": moderation(); break;
            case "relationships": relationships(); break;
            default: allPosts();
        }
    }
}
