import java.util.*;

public class Graph {
    private final Map<String, Set<String>> adjacency = new HashMap<>();

    public void addEdge(String a, String b) {
        adjacency.computeIfAbsent(a, k -> new HashSet<>()).add(b);
        adjacency.computeIfAbsent(b, k -> new HashSet<>()).add(a);
    }

    public void display() {
        System.out.println("\n--- RELATIONSHIP GRAPH ---");
        for (String node : adjacency.keySet())
            System.out.println(node + " -> " + adjacency.get(node));
    }
}
