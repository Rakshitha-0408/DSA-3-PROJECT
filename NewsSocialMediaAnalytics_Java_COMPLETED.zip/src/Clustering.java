import java.util.*;

public class Clustering {

    public static Map<String, ArrayList<Post>> clusterByTopic(ArrayList<Post> posts) {

        Map<String, ArrayList<Post>> clusters = new TreeMap<>();

        for (Post post : posts) {

            clusters.putIfAbsent(post.topic, new ArrayList<>());

            clusters.get(post.topic).add(post);
        }

        return clusters;
    }

    public static void displayClusters(ArrayList<Post> posts) {

        Map<String, ArrayList<Post>> clusters = clusterByTopic(posts);

        System.out.println("\n==============================================");
        System.out.println(" RELATED STORY CLUSTERS");
        System.out.println("==============================================");

        for (String topic : clusters.keySet()) {

            System.out.println("\nTopic: " + topic);

            for (Post post : clusters.get(topic)) {
                System.out.println("   → " + post.title);
            }
        }
    }
}