import java.util.HashMap;

public class HashTable {
    private final HashMap<String, Integer> table = new HashMap<>();

    public boolean contains(String key) {
        return table.containsKey(key);
    }

    public void put(String key, int postId) {
        table.put(key, postId);
    }

    public int get(String key) {
        return table.get(key);
    }
}
