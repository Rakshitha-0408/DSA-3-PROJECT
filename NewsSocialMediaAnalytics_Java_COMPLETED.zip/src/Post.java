public class Post {
    int id;
    String title, content, sourceType, topic;
    int priority;

    public Post(int id, String title, String content, String sourceType, String topic, int priority) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.sourceType = sourceType;
        this.topic = topic;
        this.priority = priority;
    }

    public String toString() {
        return "[" + id + "] " + title + " | " + topic + " | Priority: " + priority;
    }
}
