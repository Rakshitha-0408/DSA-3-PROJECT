import java.util.Map;
import java.util.TreeMap;
import java.util.ArrayList;

public class TopicTree {
    private final TreeMap<String, ArrayList<Post>> topics = new TreeMap<>();

    public void add(Post post) {
        topics.computeIfAbsent(post.topic, k -> new ArrayList<>()).add(post);
    }

    public void display() {
        System.out.println("\n--- TOPIC TREE ---");
        for (Map.Entry<String, ArrayList<Post>> entry : topics.entrySet()) {
            System.out.println(entry.getKey() + ":");
            for (Post p : entry.getValue())
                System.out.println("   " + p);
        }
    }
}
