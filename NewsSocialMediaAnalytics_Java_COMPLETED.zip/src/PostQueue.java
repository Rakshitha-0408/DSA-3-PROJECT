import java.util.LinkedList;
import java.util.Queue;

public class PostQueue {
    private final Queue<Post> queue = new LinkedList<>();

    public void enqueue(Post post) {
        queue.offer(post);
    }

    public Post dequeue() {
        return queue.poll();
    }

    public int size() {
        return queue.size();
    }
}
