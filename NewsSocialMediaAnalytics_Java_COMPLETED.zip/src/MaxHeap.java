import java.util.ArrayList;

public class MaxHeap {
    private final ArrayList<Post> heap = new ArrayList<>();

    public void insert(Post post) {
        heap.add(post);
        int i = heap.size() - 1;

        while (i > 0) {
            int parent = (i - 1) / 2;
            if (heap.get(parent).priority >= heap.get(i).priority) break;
            swap(parent, i);
            i = parent;
        }
    }

    public Post removeMax() {
        if (heap.isEmpty()) return null;

        Post max = heap.get(0);
        Post last = heap.remove(heap.size() - 1);

        if (!heap.isEmpty()) {
            heap.set(0, last);
            heapify(0);
        }
        return max;
    }

    private void heapify(int i) {
        while (true) {
            int left = 2 * i + 1;
            int right = 2 * i + 2;
            int largest = i;

            if (left < heap.size() &&
                heap.get(left).priority > heap.get(largest).priority)
                largest = left;

            if (right < heap.size() &&
                heap.get(right).priority > heap.get(largest).priority)
                largest = right;

            if (largest == i) break;
            swap(i, largest);
            i = largest;
        }
    }

    private void swap(int a, int b) {
        Post temp = heap.get(a);
        heap.set(a, heap.get(b));
        heap.set(b, temp);
    }
}
